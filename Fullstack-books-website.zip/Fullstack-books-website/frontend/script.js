async function loadBooks() {
    try {
        const response = await fetch("http://localhost/Fullstack-books-website/backend/getBooks.php");
        const books = await response.json();

        let container = document.getElementById("book-list");
        container.innerHTML = "";

        books.forEach(book => {
            container.innerHTML += `
                <div class="book-card">
                    <img src="../backend/uploads/${book.image}" alt="${book.title}">
                    <h2>${book.title}</h2>
                    <p>${book.author}</p>

                    <a href="update.html?id=${book.id}">
                        <button class="update-btn">Update</button>
                    </a>

                    <button onclick="deleteBook(${book.id})" class="delete-btn">Delete</button>
                </div>
            `;
        });

    } catch (error) {
        console.error("Error loading books:", error);
    }
}

async function deleteBook(id) {
    const confirmDelete = confirm("Are you sure you want to delete this book?");
    if (!confirmDelete) return;

    await fetch('http://localhost/Fullstack-books-website/backend/deleteBook.php?id=${id}');
    loadBooks();
}

window.onload = loadBooks;