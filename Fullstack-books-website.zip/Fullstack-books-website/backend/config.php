<?php
$host = "localhost";
$user = "root";   // default XAMPP user
$pass = "";
$db   = "booksdb";

$conn = mysqli_connect($host, $user, $pass, $db);

if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
}
?>