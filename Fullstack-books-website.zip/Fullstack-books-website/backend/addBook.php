<?php
include "config.php";

$title  = $_POST['title'];
$author = $_POST['author'];

$imageName = $_FILES['image']['name'];
$target = "uploads/" . basename($imageName);

move_uploaded_file($_FILES['image']['tmp_name'], $target);

$sql = "INSERT INTO books (title, author, image) VALUES ('$title', '$author', '$imageName')";
mysqli_query($conn, $sql);

echo "Book added successfully";
?>