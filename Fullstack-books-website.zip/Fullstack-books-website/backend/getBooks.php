<?php
include "config.php";

$result = mysqli_query($conn, "SELECT * FROM books");
$books = [];

while($row = mysqli_fetch_assoc($result)){
    $books[] = $row;
}

echo json_encode($books);
?>